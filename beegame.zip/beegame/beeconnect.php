<?php
$link=mysqli_connect("localhost","root","","beegame");
if (mysqli_connect_error()){

die("Could not connect to database.");
}

?>
