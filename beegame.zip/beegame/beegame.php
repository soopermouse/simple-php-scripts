<?php
require 'beeconnect.php';
 if (!empty($_GET['act'])) {
 $count=9;
$random = mt_rand(1,$count);
$query1="SELECT * FROM bees where bee_id=$random";
$result=mysqli_query($link, $query1);
$rows=array();
while($row=@mysqli_fetch_array($result)){
$rows[]=$row;
foreach($result as $row){
	$beeid=$row['bee_id'];
	$hp=$row['HP'];
	if($hp <= 0){
		echo "You have hit a dead bee.Please try again";
		break;
		}
	else{
		echo "You have hit"." ".$row['bee_name']."<br />";
echo $row['bee_name']." "."is a"." ".$row['bee_type'];
$type=$row['bee_type'];
switch($type){
case $type=="queen";
$hit=8;
break;
case $type=="worker";
$hit=10;
break;
case $type=="drone";
$hit=12;
break;
}
echo "<br />";
$newHP=$hp-$hit;
echo $row['bee_name']." "."now has"." ".$newHP." "."health points"."<br />";
$query4="UPDATE bees SET HP=$newHP WHERE bee_id='$beeid';";
$update=$result=mysqli_query($link, $query4);
if($newHP<=0){
	if($row['bee_type']=='queen'){
echo "The queen is dead"."<br />";
echo "game over"."<br />";
$query6="UPDATE bees SET HP='0';";
$update=mysqli_query($link, $query6);
echo "all bees are dead";
}else{
echo $row['bee_name']." "."is dead"."<br />";
}
}
}
}
}
}
 if (!empty($_GET['reset'])) {
$query5="UPDATE bees
SET HP = CASE bee_type
WHEN 'worker' THEN 75
WHEN 'drone' THEN 50
WHEN 'queen' THEN 100
END;";
$update=$result=mysqli_query($link, $query5);
}

?>
<html><head></head>
<body>
<br /><br /><br /><br /><br />
<button onclick="myFunction()">Hit A Bee</button>
<br /><br />
<form action="beegame.php" method="get">
  <input type="hidden" name="act" value="run">
  <input type="submit" value="Start Game">
</form>
<form action="beegame.php" method="get">
  <input type="hidden" name="reset" value="run">
  <input type="submit" value="Reset">
</form>

  
<script>
function myFunction() {
    location.reload(forceGet=true);
}
</script>
</body>