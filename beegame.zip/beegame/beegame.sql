-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2016 at 03:22 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `beegame`
--

-- --------------------------------------------------------

--
-- Table structure for table `bees`
--

CREATE TABLE IF NOT EXISTS `bees` (
  `bee_id` int(10) NOT NULL AUTO_INCREMENT,
  `bee_name` varchar(10) NOT NULL,
  `bee_type` enum('worker','drone','queen','') NOT NULL,
  `HP` int(10) NOT NULL,
  PRIMARY KEY (`bee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `bees`
--

INSERT INTO `bees` (`bee_id`, `bee_name`, `bee_type`, `HP`) VALUES
(1, 'bee1', 'worker', 75),
(2, 'bee2', 'drone', 50),
(3, 'bee3', 'worker', 75),
(4, 'bee4', 'drone', 50),
(5, 'bee5', 'queen', 100),
(6, 'bee6', 'worker', 75),
(7, 'bee7', 'drone', 50),
(8, 'bee8', 'worker', 75),
(9, 'bee9', 'drone', 50),
(10, 'bee10', 'drone', 50);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
